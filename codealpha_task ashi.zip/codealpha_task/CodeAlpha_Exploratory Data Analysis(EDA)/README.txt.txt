# Exploratory Data Analysis (EDA) – Student Performance

## Project Objective
This project focuses on performing Exploratory Data Analysis (EDA) on a student performance dataset to understand the data, identify trends and patterns, detect anomalies, and extract meaningful insights using statistics and visualizations.

## Dataset
File Name: student_performance.csv

### Columns:
- Student_ID
- Gender
- Age
- Study_Hours
- Attendance
- Math_Score
- Science_Score
- English_Score

## Questions Analyzed
- Does study time affect student performance?
- How does attendance impact overall scores?
- Is there a difference in performance based on gender?
- Which subject has the highest average score?
- Are there any noticeable patterns or anomalies in the data?

## Steps Performed
1. Loaded the dataset using Pandas
2. Checked data structure and data types
3. Verified missing values and data quality
4. Generated descriptive statistics
5. Analyzed relationships between variables
6. Created visualizations to identify trends and patterns

## Visualizations
- Study Hours vs Math Score
- Attendance vs Overall Performance
- Average Score by Subject
- Gender Distribution
- Descriptive statistics and dataset information

## Tools Used
- Python
- Jupyter Notebook
- Pandas
- Matplotlib
- Seaborn
- Anaconda

## Project Files
- Data folder containing the dataset
- Screenshots of visualizations
- eda_analysis.pdf containing full analysis and results
- README file describing the project

## Conclusion
The EDA reveals that higher study hours and better attendance generally lead to improved student performance. Visualizations helped identify clear trends and supported meaningful insights from the dataset.

## Submission
The complete Exploratory Data Analysis is documented and submitted in the eda_analysis.pdf file.
