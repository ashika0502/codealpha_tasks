README – Task 3: Data Visualization using Excel Sheets

Objective:
The objective of this task is to analyze product sales data and visualize key insights using charts in Excel / Google Sheets.

Dataset Description:
The dataset contains information about different products and includes the following columns:
1. Product – Name of the product
2. Category – Product category
3. Price – Price of the product
4. Rating – Customer rating of the product
5. Sales – Number of units sold

Tools Used:
- Google Sheets (used instead of Microsoft Excel)
- Pivot Table
- Column Charts

Charts Created:

Chart 1: Sales of Products
Description:
This chart represents the number of units sold for each product.
Insight:
- Headphones have the highest sales.
- Refrigerator has the lowest sales.
- Electronics products generally show higher sales compared to other categories.

Chart 2: Average Price by Category
Description:
This chart shows the average price of products in each category.
Insight:
- Electronics category has the highest average price.
- Clothing and Accessories have comparatively lower average prices.
- This helps understand price distribution across categories.

Chart 3: Average Rating by Category
Description:
This chart is created using a pivot table to show the average customer rating for each category.
Insight:
- Accessories and Electronics have the highest average ratings.
- All categories have ratings above 4, indicating good customer satisfaction.

Conclusion:
This task helped in understanding how to visualize sales data effectively using charts. 
Charts make it easier to identify trends, compare categories, and draw meaningful insights from raw data.

Files Submitted:
- Excel Sheet containing dataset and charts
- Screenshots of dataset, pivot table, and all charts
- README file with explanation

