# Task 1: Web Scraping using Octoparse

## Project Title
Web Scraping of Quotes Data

## Description
This project demonstrates the process of web scraping using a no-code automation tool called Octoparse.
The objective of this task is to extract structured data from a public website and create a dataset that can be used for analysis.

The data was collected from a quotes website, where information such as quotes, authors, and related tags was extracted and stored in an Excel file.

## Tool Used
- Octoparse (No-code web scraping tool)
- Microsoft Excel

## Website Scraped
https://quotes.toscrape.com

(This is a public website used for learning and practice purposes.)

## Data Extracted
The following data fields were extracted:
- Quote
- Author
- Author About Page URL
- Tags related to each quote
- Tag URLs

A total of 100 records were successfully extracted with 0 duplicate entries.

## Steps Followed
1. Opened Octoparse and created a new task
2. Entered the website URL
3. Selected required page elements (quotes, authors, tags)
4. Used automatic workflow creation
5. Ran the task using local extraction
6. Exported the extracted data into an Excel file

## Output
- Quotes_to_Scrape.xlsx
  - Contains structured data extracted from the website
  - Ready for further analysis

## Conclusion
This task helped in understanding the basics of web scraping and data collection using automated tools.
It demonstrates how relevant datasets can be collected efficiently without manual copying and can be stored in structured formats for analysis.